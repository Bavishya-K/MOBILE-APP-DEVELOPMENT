package video.api.flutter.player.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
