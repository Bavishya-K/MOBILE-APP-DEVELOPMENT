#import <Flutter/Flutter.h>

@interface ApiVideoPlayerPlugin : NSObject<FlutterPlugin>
@end
